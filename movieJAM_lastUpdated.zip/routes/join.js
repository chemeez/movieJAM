var express = require('express');
var router = express.Router();

/* 1/3 페이지 (본인 확인) */
router.get('/', function(req, res) {
    res.render('join/join1', { layout: false });
});

module.exports = router;
